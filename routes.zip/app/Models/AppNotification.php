<?php

namespace App\Models;

//use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model;


class AppNotification extends Model
{
    //
    protected $table = 'app_notifications';

}
