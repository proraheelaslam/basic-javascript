<?php

namespace App\models;

use Jenssegers\Mongodb\Eloquent\Model;

class City extends Model
{
    protected $table = "cities";

    
}
