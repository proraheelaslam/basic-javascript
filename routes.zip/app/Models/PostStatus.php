<?php

namespace App\Models;

//use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model;


class PostStatus extends Model
{
    //
    protected $table = "post_status";
}
