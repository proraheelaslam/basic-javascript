<p>
    {!! @$mailData['content'] !!}
</p>