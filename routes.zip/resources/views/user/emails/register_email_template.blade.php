<p>
    {!! @$mailData['desc'] !!}
</p>