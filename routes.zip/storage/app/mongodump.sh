#!/bin/sh

 mongodump --db nextneigbour