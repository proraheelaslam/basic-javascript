<p>
    <?php echo @$mailData['content']; ?>

</p>