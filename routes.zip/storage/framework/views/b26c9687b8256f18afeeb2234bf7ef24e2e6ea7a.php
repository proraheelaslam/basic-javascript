<p>
    <?php echo @$mailData['desc']; ?>

</p>